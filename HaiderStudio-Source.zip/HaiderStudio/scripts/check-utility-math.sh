#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v swiftc >/dev/null; then
  echo 'Swift compiler required for utility checks.' >&2
  exit 1
fi
check_dir="$(mktemp -d)"
trap 'rm -rf "$check_dir"' EXIT
swiftc iOS/HaiderStudio/Core/UtilityMath.swift tests/UtilityMathChecks.swift -o "$check_dir/UtilityMathChecks"
"$check_dir/UtilityMathChecks"
