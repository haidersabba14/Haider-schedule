from pathlib import Path
import hashlib
root = Path(__file__).resolve().parents[1]
def uid(s): return hashlib.sha1(s.encode()).hexdigest()[:24].upper()
def q(s): return '"'+s.replace('"','\\"')+'"'
objects=[]
def obj(key,body):
 i=uid(key);objects.append(f'{i} = {{ {body} }};');return i
source=root/'iOS/HaiderStudio'
refs=[]; builds=[]; resources=[]
for p in sorted(source.rglob('*.swift')):
 rel=p.relative_to(root).as_posix()
 ref=obj('ref:'+rel,f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {q(rel)}; sourceTree = SOURCE_ROOT;')
 refs.append(ref)
 builds.append(obj('build:'+rel,f'isa = PBXBuildFile; fileRef = {ref};'))
for rel,typ in [('iOS/HaiderStudio/Assets.xcassets','folder.assetcatalog'),('iOS/HaiderStudio/PrivacyInfo.xcprivacy','text.xml')]:
 ref=obj('ref:'+rel,f'isa = PBXFileReference; lastKnownFileType = {typ}; path = {q(rel)}; sourceTree = SOURCE_ROOT;');refs.append(ref)
 resources.append(obj('build:'+rel,f'isa = PBXBuildFile; fileRef = {ref};'))
localized=[]
for lang in ['en','ar']:
 localized.append(obj('lang:'+lang,f'isa = PBXFileReference; lastKnownFileType = text.plist.strings; name = {lang}; path = {q("iOS/HaiderStudio/"+lang+".lproj/Localizable.strings")}; sourceTree = SOURCE_ROOT;'))
variant=obj('localization','isa = PBXVariantGroup; children = ('+','.join(localized)+',); name = Localizable.strings; sourceTree = "<group>";');refs.append(variant)
resources.append(obj('build:localization',f'isa = PBXBuildFile; fileRef = {variant};'))
app=obj('app','isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = HaiderStudio.app; sourceTree = BUILT_PRODUCTS_DIR;')
products=obj('products',f'isa = PBXGroup; children = ({app},); name = Products; sourceTree = "<group>";')
main=obj('main','isa = PBXGroup; children = ('+','.join(refs+[products])+',); sourceTree = "<group>";')
sources=obj('sources','isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ('+','.join(builds)+',); runOnlyForDeploymentPostprocessing = 0;')
res=obj('resources','isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = ('+','.join(resources)+',); runOnlyForDeploymentPostprocessing = 0;')
frameworks=obj('frameworks','isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
project_configs=[];target_configs=[]
for mode in ['Debug','Release']:
 project_configs.append(obj('project:'+mode,'isa = XCBuildConfiguration; name = '+mode+'; buildSettings = { CLANG_ENABLE_MODULES = YES; SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 17.0; SWIFT_VERSION = 5.0; '+ ('SWIFT_OPTIMIZATION_LEVEL = "-Onone"; DEBUG_INFORMATION_FORMAT = dwarf; SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG;' if mode=='Debug' else 'SWIFT_OPTIMIZATION_LEVEL = "-O"; DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym";')+' };'))
 target_configs.append(obj('target:'+mode,'isa = XCBuildConfiguration; name = '+mode+'; buildSettings = { PRODUCT_NAME = HaiderStudio; PRODUCT_BUNDLE_IDENTIFIER = com.haiderstudio.ultimate; INFOPLIST_FILE = iOS/HaiderStudio/Info.plist; ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; CODE_SIGN_STYLE = Automatic; TARGETED_DEVICE_FAMILY = 1; SUPPORTED_PLATFORMS = "iphoneos iphonesimulator"; SUPPORTS_MACCATALYST = NO; GENERATE_INFOPLIST_FILE = NO; SWIFT_EMIT_LOC_STRINGS = YES; ENABLE_USER_SCRIPT_SANDBOXING = YES; LD_RUNPATH_SEARCH_PATHS = "$(inherited) @executable_path/Frameworks"; };'))
pc=obj('projectconfigs','isa = XCConfigurationList; buildConfigurations = ('+','.join(project_configs)+',); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
tc=obj('targetconfigs','isa = XCConfigurationList; buildConfigurations = ('+','.join(target_configs)+',); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
target=obj('target',f'isa = PBXNativeTarget; buildConfigurationList = {tc}; buildPhases = ({sources},{frameworks},{res},); buildRules = (); dependencies = (); name = HaiderStudio; productName = HaiderStudio; productReference = {app}; productType = "com.apple.product-type.application";')
project=obj('project',f'isa = PBXProject; attributes = {{ BuildIndependentTargetsInParallel = YES; LastUpgradeCheck = 1600; }}; buildConfigurationList = {pc}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en,ar,Base,); mainGroup = {main}; productRefGroup = {products}; projectDirPath = ""; projectRoot = ""; targets = ({target},);')
(root/'HaiderStudio.xcodeproj/project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+'\n'.join(objects)+'\n}; rootObject = '+project+'; }\n')
scheme=root/'HaiderStudio.xcodeproj/xcshareddata/xcschemes/HaiderStudio.xcscheme';scheme.parent.mkdir(parents=True,exist_ok=True)
scheme.write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="HaiderStudio.app" BlueprintName="HaiderStudio" ReferencedContainer="container:HaiderStudio.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="HaiderStudio.app" BlueprintName="HaiderStudio" ReferencedContainer="container:HaiderStudio.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="HaiderStudio.app" BlueprintName="HaiderStudio" ReferencedContainer="container:HaiderStudio.xcodeproj"/></BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
print(f'Generated project with {len(builds)} Swift source files.')
