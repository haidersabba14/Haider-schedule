#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]] || ! command -v xcodebuild >/dev/null; then
  echo 'A Mac with Xcode and iOS SDK is required. No IPA was created.' >&2
  exit 1
fi
bash scripts/check-utility-math.sh
: "${DEVELOPMENT_TEAM:?Set DEVELOPMENT_TEAM to your Apple team ID}"
: "${EXPORT_OPTIONS_PLIST:?Set EXPORT_OPTIONS_PLIST to your signed export options plist}"
xcodebuild -project HaiderStudio.xcodeproj -scheme HaiderStudio -configuration Release -destination 'generic/platform=iOS' -archivePath build/HaiderStudio.xcarchive DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" archive
xcodebuild -exportArchive -archivePath build/HaiderStudio.xcarchive -exportPath build/export -exportOptionsPlist "$EXPORT_OPTIONS_PLIST"
test -s build/export/HaiderStudio.ipa
echo 'Created build/export/HaiderStudio.ipa'
