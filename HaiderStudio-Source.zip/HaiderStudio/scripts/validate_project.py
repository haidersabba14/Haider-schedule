"""Checks packaging consistency only. Does not compile Swift or validate Xcode semantics."""
from pathlib import Path
import json, plistlib, re, xml.etree.ElementTree as ET
from PIL import Image
root = Path(__file__).resolve().parents[1]
project = (root/'HaiderStudio.xcodeproj/project.pbxproj').read_text()
ids = re.findall(r'^([A-F0-9]{24}) = ', project, re.M)
assert len(ids) == len(set(ids)), 'Duplicate project IDs'
for ref in re.findall(r'\b[A-F0-9]{24}\b', project):
    assert ref in ids, f'Undefined project reference {ref}'
for path in re.findall(r'path = "([^"]+)"; sourceTree = SOURCE_ROOT;', project):
    assert (root/path).exists(), f'Missing Xcode resource {path}'
for source in (root/'iOS/HaiderStudio').rglob('*.swift'):
    assert str(source.relative_to(root)) in project, f'Unlisted Swift file {source}'
for file in list(root.rglob('*.plist')) + list(root.rglob('*.xcprivacy')):
    plistlib.loads(file.read_bytes())
for file in root.rglob('*.xcscheme'):
    ET.parse(file)
for file in root.rglob('Contents.json'):
    value = json.loads(file.read_text())
    for image in value.get('images', []):
        if image.get('filename'): assert (file.parent/image['filename']).exists()
icon = Image.open(root/'iOS/HaiderStudio/Assets.xcassets/AppIcon.appiconset/AppIcon.png')
assert icon.size == (1024,1024) and icon.mode == 'RGB'
for lang in ['ar','en']:
    file = root/f'iOS/HaiderStudio/{lang}.lproj/Localizable.strings'
    keys = []
    for line in file.read_text().splitlines():
        if not line.strip(): continue
        match = re.fullmatch(r'("(?:[^"\\]|\\.)*") = ("(?:[^"\\]|\\.)*");', line)
        assert match, f'Malformed localization: {line}'
        keys.append(json.loads(match.group(1)))
    assert len(keys) == len(set(keys)), f'Duplicate localization keys in {lang}'
count = len(list((root/'iOS/HaiderStudio').rglob('*.swift')))
print(f'PASS: {len(ids)} Xcode objects; {count} Swift file references; plists, scheme, assets and localizations consistent.')
print('This check validates packaging only. Build evidence and remaining checks are recorded in docs/TESTING.md.')
