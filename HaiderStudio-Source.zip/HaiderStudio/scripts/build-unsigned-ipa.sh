#!/bin/bash
# Build a real iPhone binary on macOS, then package it for external signing.
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]] || ! command -v xcodebuild >/dev/null; then
  echo 'macOS and Xcode are required. No IPA was created.' >&2
  exit 1
fi
archive="$PWD/build/unsigned/HaiderStudio.xcarchive"
output="$PWD/build/unsigned/HaiderStudio.ipa"
staging="$(mktemp -d)"
trap 'rm -rf "$staging"' EXIT
mkdir -p "$(dirname "$output")"
rm -f "$output"
xcodebuild -project HaiderStudio.xcodeproj -scheme HaiderStudio \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath "$archive" CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' archive
app="$archive/Products/Applications/HaiderStudio.app"
test -d "$app"
test -s "$app/HaiderStudio"
/usr/bin/plutil -lint "$app/Info.plist"
# Reject simulator apps or empty placeholder executables.
/usr/bin/lipo "$app/HaiderStudio" -verify_arch arm64
platform="$(/usr/libexec/PlistBuddy -c 'Print :DTPlatformName' "$app/Info.plist")"
[[ "$platform" == iphoneos ]]
mkdir -p "$staging/Payload"
/usr/bin/ditto "$app" "$staging/Payload/HaiderStudio.app"
(cd "$staging" && /usr/bin/zip -qry "$output" Payload)
/usr/bin/unzip -tq "$output"
/usr/bin/shasum -a 256 "$output" > "$output.sha256"
echo "Created real device build: $output"
echo 'UNSIGNED: requires compatible signing/installation. Ordinary iPhones cannot install it directly.'
