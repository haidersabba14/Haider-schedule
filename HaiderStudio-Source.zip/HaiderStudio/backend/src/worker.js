const modes = Object.freeze({
  chat: 'You are a helpful creative assistant. Respond in the user’s language.',
  write: 'Help draft high-quality original writing in the requested language.',
  summarize: 'Summarize the supplied text accurately. Do not invent facts.',
  translate: 'Translate the supplied text to the target language the user specifies. Ask for clarification if no target is provided.',
  correct: 'Correct spelling and grammar while preserving meaning.',
  code: 'Help write code. Explain limitations. Do not claim you executed code.',
  explain: 'Explain the supplied code clearly and flag issues you can identify.'
});
const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' };
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers });

export function validatePayload(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return 'Expected a JSON object.';
  if (typeof value.mode !== 'string' || !Object.hasOwn(modes, value.mode)) return 'Unsupported AI task.';
  if (typeof value.prompt !== 'string' || !value.prompt.trim() || value.prompt.length > 12000) return 'Prompt must contain 1–12000 characters.';
  if (Object.keys(value).some(key => !['mode', 'prompt'].includes(key))) return 'Unexpected request fields.';
  return null;
}

export async function readBoundedJSON(request) {
  const max = 64000;
  if (Number(request.headers.get('content-length') || 0) > max) throw new Error('Body too large.');
  if (!request.body) throw new Error('Missing request body.');
  const reader = request.body.getReader();
  let size = 0;
  const chunks = [];
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > max) { await reader.cancel(); throw new Error('Body too large.'); }
    chunks.push(value);
  }
  const data = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { data.set(chunk, offset); offset += chunk.byteLength; }
  return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(data));
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.protocol !== 'https:' && url.hostname !== 'localhost') return json({ error: 'HTTPS required.' }, 400);
    if (url.pathname === '/health' && request.method === 'GET') return json({ status: 'ok', aiConfigured: Boolean(env.OPENAI_API_KEY) });
    if (url.pathname !== '/v1/ai') return json({ error: 'Not found.' }, 404);
    if (request.method !== 'POST') return json({ error: 'POST required.' }, 405);
    if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) return json({ error: 'JSON content type required.' }, 415);
    if (!env.OPENAI_API_KEY) return json({ error: 'AI provider is not configured. The operator must add OPENAI_API_KEY to Cloudflare Secrets.' }, 503);
    let payload;
    try { payload = await readBoundedJSON(request); } catch { return json({ error: 'Malformed or oversized JSON body.' }, 400); }
    const invalid = validatePayload(payload);
    if (invalid) return json({ error: invalid }, 400);
    if (!env.LIMITS) return json({ error: 'Rate limiter is not configured.' }, 503);
    try {
      // One globally serialized object enforces both IP limits and an operator-wide daily budget.
      // No reusable provider or gateway secret is shipped in the IPA.
      const ip = request.headers.get('CF-Connecting-IP');
      if (!ip) return json({ error: 'Client identity unavailable.' }, 403);
      const budget = Number(env.DAILY_REQUEST_BUDGET);
      if (!Number.isSafeInteger(budget) || budget < 1 || budget > 10000) return json({ error: 'Invalid server budget configuration.' }, 503);
      const limiter = env.LIMITS.get(env.LIMITS.idFromName('global-v1'));
      const permit = await limiter.fetch('https://limits.internal/check', { method: 'POST', body: JSON.stringify({ ip, budget }) });
      if (!permit.ok) return json({ error: 'Rate or daily usage limit reached. Try later.' }, 429);
      const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { authorization: `Bearer ${env.OPENAI_API_KEY}`, 'content-type': 'application/json' },
        body: JSON.stringify({ model: env.AI_MODEL || 'gpt-4.1-mini', messages: [{ role: 'system', content: modes[payload.mode] }, { role: 'user', content: payload.prompt }], max_completion_tokens: 1200 }),
        signal: AbortSignal.timeout(60000)
      });
      if (!upstream.ok) {
        // Do not log prompts, IPs, provider bodies or credentials.
        console.warn(JSON.stringify({ event: 'provider_error', status: upstream.status }));
        return json({ error: upstream.status === 429 ? 'AI provider usage limit reached.' : 'AI provider request failed. Check provider billing and server configuration.' }, 502);
      }
      const body = await upstream.json();
      const text = body.choices?.[0]?.message?.content;
      if (typeof text !== 'string' || !text.trim()) return json({ error: 'Provider returned no text.' }, 502);
      console.log(JSON.stringify({ event: 'ai_completed', tokens: body.usage?.total_tokens ?? null }));
      return json({ text });
    } catch {
      return json({ error: 'Cloud request failed or timed out. Local projects remain safe.' }, 502);
    }
  }
};

export class RequestBudget {
  constructor(state) { this.state = state; }
  async fetch(request) {
    const { ip, budget } = await request.json();
    if (typeof ip !== 'string' || ip.length > 100 || !Number.isSafeInteger(budget) || budget < 1) return new Response(null, { status: 400 });
    const now = Date.now();
    const day = Math.floor(now / 86400000);
    const minute = Math.floor(now / 60000);
    // Hash before persistent storage; never persist the raw client IP.
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${day}:${ip}`));
    const hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
    const allowed = await this.state.storage.transaction(async txn => {
      let usage = await txn.get('usage') || { day, count: 0, minute, clients: {} };
      if (usage.day !== day) usage = { day, count: 0, minute, clients: {} };
      if (usage.minute !== minute) { usage.minute = minute; usage.clients = {}; }
      const count = usage.clients[hash] || 0;
      if (count >= 6 || usage.count >= budget) return false;
      usage.clients[hash] = count + 1; usage.count += 1;
      await txn.put('usage', usage);
      return true;
    });
    if (!(await this.state.storage.getAlarm())) await this.state.storage.setAlarm((day + 1) * 86400000);
    return new Response(null, { status: allowed ? 204 : 429 });
  }
  async alarm() {
    const usage = await this.state.storage.get('usage');
    const day = Math.floor(Date.now() / 86400000);
    if (!usage || usage.day < day) await this.state.storage.deleteAll();
    else await this.state.storage.setAlarm((day + 1) * 86400000);
  }
}
