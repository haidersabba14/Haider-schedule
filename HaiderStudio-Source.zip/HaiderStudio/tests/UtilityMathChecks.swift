import Foundation

@main
struct UtilityMathChecks {
    static func main() throws {
        func close(_ actual: Double, _ expected: Double) {
            precondition(abs(actual - expected) < 1e-9, "Expected \(expected), got \(actual)")
        }
        func rejects(_ action: () throws -> Double) {
            do { _ = try action(); preconditionFailure("Expected invalid input to be rejected") } catch { }
        }
        precondition(UtilityMath.number("١٢٫٥") == 12.5)
        precondition(UtilityMath.number("−3,5") == -3.5)
        precondition(UtilityMath.number("1e2") == 100)
        for text in ["12abc", "nan", "inf", "", "1,2,3", "1e999"] { precondition(UtilityMath.number(text) == nil) }
        close(try UtilityMath.calculate("+", a: 2, b: 3), 5)
        close(try UtilityMath.calculate("sin", a: 30), 0.5)
        close(try UtilityMath.calculate("cos", a: .pi, degrees: false), -1)
        close(try UtilityMath.calculate("n!", a: 0), 1)
        close(try UtilityMath.calculate("n!", a: 5), 120)
        rejects { try UtilityMath.calculate("÷", a: 1, b: 0) }
        rejects { try UtilityMath.calculate("√", a: -1) }
        rejects { try UtilityMath.calculate("tan", a: 90) }
        rejects { try UtilityMath.calculate("n!", a: 1.5) }
        rejects { try UtilityMath.calculate("n!", a: 171) }
        rejects { try UtilityMath.calculate("+", a: 1) }
        close(try UtilityMath.convert(32, sourceFactor: 5.0/9, sourceOffset: -32 * 5.0/9, targetFactor: 1, targetOffset: 0, temperature: true), 0)
        close(try UtilityMath.convert(0, sourceFactor: 1, sourceOffset: 0, targetFactor: 1, targetOffset: -273.15, temperature: true), 273.15)
        close(try UtilityMath.convert(1, sourceFactor: 1024, sourceOffset: 0, targetFactor: 1000, targetOffset: 0), 1.024)
        rejects { try UtilityMath.convert(-274, sourceFactor: 1, sourceOffset: 0, targetFactor: 1, targetOffset: 0, temperature: true) }
        rejects { try UtilityMath.convert(1, sourceFactor: 1, sourceOffset: 0, targetFactor: 0, targetOffset: 0) }
        print("PASS: numeric input, calculator domain errors and conversion checks")
    }
}
