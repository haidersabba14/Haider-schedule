# البناء والتثبيت

## المتطلبات

- macOS يدعم Xcode 16 أو أحدث، وiOS SDK وCommand Line Tools مفعلة.
- iPhone بنظام iOS 17+ أو Simulator مناسب.
- حساب Apple للتثبيت على جهاز. عضوية Apple Developer وشهادات وProvisioning Profiles مناسبة عند تصدير IPA للتوزيع. حساب مجاني قد يتيح التشغيل من Xcode بقيود Apple، لكنه لا يعادل توزيع Ad Hoc أو App Store.
- لا أسرار أو شهادات أو provisioning profiles داخل المشروع.

## تحقق التجميع

```sh
xcodebuild -project HaiderStudio.xcodeproj -scheme HaiderStudio \
  -configuration Debug -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

هذا الأمر لا ينتج IPA قابلًا للتثبيت على iPhone. راجع تحذيرات/أخطاء Xcode الفعلية وأصلحها قبل اعتبار المشروع جاهزًا للتوزيع. لا توجد نتيجة بناء مسجلة لهذا المشروع بعد.

## Archive وIPA

في Xcode:
1. اختر target HaiderStudio، ثم Signing & Capabilities، ثم Team ومعرف حزمة تملكه.
2. اختر Any iOS Device، ثم Product → Archive.
3. افتح Organizer → Distribute App واختر طريقة التوزيع الملائمة لحسابك وأجهزتك. الصلاحيات والتوقيع من Apple، لا يمكن اختلاقها في المشروع.
4. صدّر إلى `build/export`، ويكون اسم المنتج `HaiderStudio.ipa` إذا نجح التصدير.

أو جهّز ExportOptions.plist من إعدادات التوزيع المناسبة ثم:

```sh
DEVELOPMENT_TEAM=YOUR_TEAM_ID \
EXPORT_OPTIONS_PLIST=/absolute/path/ExportOptions.plist \
./scripts/build-ipa.sh
```

يتوقف السكربت صراحةً إذا غاب Xcode أو فشل البناء. لا ينشئ Archive أو IPA وهميًا. لا يعدّل إعدادات حسابك ولا يرفع التطبيق تلقائيًا.

## التثبيت

للتطوير استخدم Run من Xcode على الجهاز. للتوزيع استخدم TestFlight أو طريقة Apple المعتمدة والمناسبة للتوقيع. تثبيت IPA جانبيًا يتطلب توقيعًا وصلاحيات متوافقة مع وسيلة التثبيت والجهاز.

## TrollStore

لا يمكن ضمان توافق TrollStore بمجرد تغيير امتداد الملف. المشروع لا يستخدم entitlements خاصة أو استغلالات أمنية. دعم TrollStore يعتمد على الجهاز وإصدار iOS وإصدار TrollStore، ويجب التحقق من وثائق المشروع الرسمية وقت التثبيت.

**الحد الأدنى لهذا التطبيق iOS 17.0**؛ لذلك لا يعمل على أجهزة TrollStore ذات iOS 14/15/16. يشمل نطاق TrollStore المعروف بعض الأجهزة على iOS 17.0 بالضبط، وليس كل iOS 17 وما بعده. هذا المشروع لم يُختبر بواسطة TrollStore ولا يُدّعى دعمه الفعلي حتى الاختبار على جهاز متوافق. دعم إصدارات أقدم يتطلب خفض deployment target واستبدال واجهات iOS 17 واختبارها.

## بناء IPA عبر GitHub Actions بدون Mac محلي

أضيف مسار `.github/workflows/ipa.yml` لبناء **نسخة iPhone حقيقية غير موقعة** على `macos-15` ثم وضع التطبيق المبني داخل `Payload/HaiderStudio.app` وإنتاج `HaiderStudio.ipa`. لا يجري تغليف أي مجلد إذا فشل Archive. يفحص السكربت وجود executable وarm64 ومنصة iphoneos وصحة ZIP.

1. ارفع محتويات المشروع إلى جذر مستودع GitHub، بحيث يكون `HaiderStudio.xcodeproj` و`.github` في الجذر، وليس داخل مجلد إضافي.
2. افتح Actions → Build iPhone IPA (unsigned) → Run workflow.
3. بعد نجاح التشغيل، حمّل artifact المسمى `HaiderStudio-unsigned-IPA`، وافك ZIP للوصول إلى `HaiderStudio.ipa` وبصمة SHA-256.
4. إن فشل البناء، لا يوجد IPA صالح؛ راجع سجل الخطوة لإصلاح أخطاء Xcode.

هذا المسار لا يحتاج شهادات Apple لأنه **لا يوقع** التطبيق. الناتج لا يُثبّت مباشرة على iPhone عادي: يحتاج توقيعًا مناسبًا عبر وسيلة تثبيت موثوقة أو مسار تثبيت متوافقًا فعليًا مع جهازك. لا يعني إنشاء IPA ضمان توافق TrollStore. راجع قيود iOS 17.0 المذكورة أعلاه.

لتصدير IPA موقّع استخدم `scripts/build-ipa.sh` مع Team وشهادات وملف provisioning وExportOptions مناسبة. لا ترفع شهادة أو كلمة مرور أو مفتاح AI إلى ملفات المستودع. البناء عبر Actions قد يستهلك رصيد GitHub Actions حسب خطة المستودع؛ المسار الخاص بـIPA يدوي التشغيل فقط.

**لم يُشغّل هذا workflow من الجلسة الحالية بعد؛ يلزم مستودع GitHub متاح وتشغيل فعلي لإثبات نجاحه.**


## تحديث نتيجة البناء الفعلية — 30 أكتوبر 2026

تمت مراجعة سجل GitHub Actions للتشغيل 41020950218 في مستودع haidersabba14/Haider-schedule. نجحت اختبارات الخلفية، وتجميع iOS باستخدام Xcode 16.4 وإنشاء Archive (`ARCHIVE SUCCEEDED`). فشل تغليف IPA بعد ذلك بسبب ترتيب معاملات أمر lipo؛ صُحح السكربت ليضع ملف التنفيذ قبل `-verify_arch arm64`.

هذا يثبت نجاح تجميع نسخة المصدر السابقة وArchive على خادم macOS، وليس اختبار التطبيق على جهاز. لم يُنفذ السكربت المصحح على macOS بعد، ولم يُنتج IPA ناجح بعد. أي عبارات سابقة عن عدم تنفيذ بناء Xcode تصف حالة التسليم الأول، وتتحدث نتيجة البناء هذه عن الحالة الأحدث.
