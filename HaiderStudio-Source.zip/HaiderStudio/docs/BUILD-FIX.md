# إصلاح فحص arm64

السبب: اعتبر lipo مسار الملف معمارية إضافية لأن `-verify_arch` يقبل قائمة معاملات حتى نهاية الأمر.

قبل:
```sh
/usr/bin/lipo -verify_arch arm64 "$app/HaiderStudio"
```

بعد:
```sh
/usr/bin/lipo "$app/HaiderStudio" -verify_arch arm64
```

لم يُحذف فحص المعمارية أو أي تحقق آخر. لم تُعدل مصادر Swift التي اجتازت Archive. بعد استبدال ZIP داخل المستودع، ابدأ Run workflow جديدًا على main؛ إعادة تشغيل التشغيل القديم تستخدم commit القديم والسكربت القديم.
