import SwiftUI
import UniformTypeIdentifiers

struct RootView: View {
    @EnvironmentObject var connection: ConnectionMonitor
    var body: some View {
        ZStack {
            TabView {
                NavigationStack { HomeView() }.tabItem { Label("Home", systemImage: "square.grid.2x2") }
                NavigationStack { AIView() }.tabItem { Label("AI Studio", systemImage: "sparkles") }
                NavigationStack { ProjectsView() }.tabItem { Label("My Projects", systemImage: "folder") }
                NavigationStack { SettingsView() }.tabItem { Label("Settings", systemImage: "gearshape") }
            }.tint(.purple)
            if !connection.online {
                ZStack {
                    StudioBackground()
                    VStack(spacing: 24) {
                        Image(systemName: "wifi.slash").font(.system(size: 64)).foregroundStyle(studioGradient)
                        Text("No Internet Connection").font(.title2.bold())
                        Text("Connect to the internet to use HAIDER STUDIO.").multilineTextAlignment(.center)
                        if connection.checking { ProgressView() }
                        Button("Retry", systemImage: "arrow.clockwise") { connection.retry() }.buttonStyle(.borderedProminent)
                    }.padding(32)
                }.transition(.opacity)
            }
        }
    }
}
struct HomeView: View {
    @State private var search = ""
    var body: some View {
        ZStack {
            StudioBackground()
            ScrollView {
                VStack(spacing: 18) {
                    Image("BrandLogo").resizable().scaledToFit().frame(height: 190).accessibilityLabel("HAIDER STUDIO")
                    Text("Create something extraordinary").font(.title2.bold())
                    Label("Online · Local projects stay on your device", systemImage: "network").font(.caption).foregroundStyle(.secondary)
                    ForEach(StudioTool.allCases.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) }) { tool in
                        NavigationLink { tool.destination } label: {
                            StudioCard {
                                HStack(spacing: 16) {
                                    Image(systemName: tool.icon).font(.title).foregroundStyle(studioGradient).frame(width: 40)
                                    VStack(alignment: .leading) { Text(LocalizedStringKey(tool.title)).font(.headline); Text(LocalizedStringKey(tool.subtitle)).font(.caption).foregroundStyle(.secondary) }
                                    Spacer(); Image(systemName: "chevron.forward")
                                }.frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }.buttonStyle(.plain)
                    }
                }.padding()
            }
        }.navigationTitle("HAIDER STUDIO").searchable(text: $search, prompt: "Search tools")
    }
}
enum StudioTool: String, CaseIterable, Identifiable {
    case photo, pdf, video, audio, design, game, code, tools
    var id: String { rawValue }
    var title: String { switch self { case .photo: "Photo Studio"; case .pdf: "PDF Studio"; case .video: "Video Studio"; case .audio: "Audio Studio"; case .design: "Design Studio"; case .game: "Game Studio"; case .code: "Code Studio"; case .tools: "Advanced Tools" } }
    var subtitle: String { switch self { case .photo: "Adjust, rotate, resize and export"; case .pdf: "Images to PDF, merge and extract text"; case .video: "Trim and export video"; case .audio: "Record and play audio"; case .design: "Create text and gradient artwork"; case .game: "Play a SpriteKit prototype"; case .code: "Edit HTML and preview locally"; case .tools: "QR, passwords, colors and notes" } }
    var icon: String { switch self { case .photo: "photo"; case .pdf: "doc.richtext"; case .video: "film"; case .audio: "waveform"; case .design: "paintpalette"; case .game: "gamecontroller"; case .code: "curlybraces"; case .tools: "wrench.and.screwdriver" } }
    @ViewBuilder var destination: some View { switch self { case .photo: PhotoEditorView(); case .pdf: PDFStudioView(); case .video: VideoStudioView(); case .audio: AudioStudioView(); case .design: DesignStudioView(); case .game: GameStudioView(); case .code: CodeStudioView(); case .tools: ToolsView() } }
}
struct ProjectsView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var importing = false
    @State private var query = ""
    var body: some View {
        List {
            ErrorBanner(message: store.error)
            ForEach(store.items.filter { query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) }) { item in
                VStack(alignment: .leading) {
                    Text(item.name).font(.headline)
                    Text(item.created, style: .date).font(.caption)
                    ShareLink(item: store.url(item)) { Label("Export file", systemImage: "square.and.arrow.up") }
                }.swipeActions { Button("Delete", role: .destructive) { do { try store.delete(item) } catch { store.error = error.localizedDescription } } }
            }
            if store.items.isEmpty { Text("Saved exports appear here.").foregroundStyle(.secondary) }
        }.navigationTitle("My Projects").searchable(text: $query)
            .toolbar { Button("Import", systemImage: "plus") { importing = true } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data]) { result in
                do { try store.importFile(result.get()) } catch { store.error = error.localizedDescription }
            }
    }
}
struct SettingsView: View {
    @AppStorage("appearance") private var appearance = "dark"
    @AppStorage("language") private var language = "ar"
    @AppStorage("backendURL") private var backendURL = ""
    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $appearance) { Text("Dark").tag("dark"); Text("Light").tag("light"); Text("System").tag("system") }
                Picker("Language", selection: $language) { Text("العربية").tag("ar"); Text("English").tag("en") }
            }
            Section("Cloud services") {
                TextField("https://your-worker.workers.dev", text: $backendURL).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Text("Deploy the included Worker and add provider secrets before using AI. Provider usage may incur charges.").font(.caption)
            }
            Section("Privacy") {
                Text("Projects are stored locally with iOS file protection. Only text you explicitly approve is sent to your configured AI gateway. Internet verification contacts Apple. No ads or tracking SDKs. Delete local projects from My Projects. Exported files must be deleted separately.")
            }
            Section("Build status") {
                Text("1.0.0 · Development preview")
                Text("Advanced timelines, AI image tools, project encryption/Face ID and a complete game editor are not implemented in this preview.").font(.caption)
            }
        }.navigationTitle("Settings")
    }
}
