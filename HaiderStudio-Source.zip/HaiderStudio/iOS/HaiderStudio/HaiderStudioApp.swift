import SwiftUI

@main
struct HaiderStudioApp: App {
    @StateObject private var projects = ProjectStore()
    @StateObject private var connection = ConnectionMonitor()
    @AppStorage("appearance") private var appearance = "dark"
    @AppStorage("language") private var language = "ar"
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(projects).environmentObject(connection)
                .preferredColorScheme(appearance == "system" ? nil : appearance == "dark" ? .dark : .light)
                .environment(\.locale, Locale(identifier: language))
                .environment(\.layoutDirection, language == "ar" ? .rightToLeft : .leftToRight)
        }
    }
}
