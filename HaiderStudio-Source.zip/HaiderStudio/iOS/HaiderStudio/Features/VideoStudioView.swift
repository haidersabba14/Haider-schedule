import SwiftUI
import AVKit
import UniformTypeIdentifiers

struct VideoStudioView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var importing = false
    @State private var source: URL?
    @State private var player: AVPlayer?
    @State private var duration = 0.0
    @State private var start = 0.0
    @State private var end = 0.0
    @State private var busy = false
    @State private var exported: URL?
    @State private var error: String?
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Button("Import video") { importing = true }.disabled(busy)
                if let player { VideoPlayer(player: player).frame(height: 270) }
                if duration > 0 {
                    Text("Start: \(start, specifier: "%.1f") s")
                    Slider(value: $start, in: 0...duration).onChange(of: start) { player?.seek(to: CMTime(seconds: start, preferredTimescale: 600)) }
                    Text("End: \(end, specifier: "%.1f") s")
                    Slider(value: $end, in: 0...duration)
                    Button("Export trimmed video (1080p)") { Task { await export() } }.buttonStyle(.borderedProminent).disabled(busy || end <= start)
                }
                if busy { ProgressView("Exporting…") }
                if let exported { ShareLink(item: exported) }
                ErrorBanner(message: error)
            }.padding()
        }.navigationTitle("Video Studio")
            .fileImporter(isPresented: $importing, allowedContentTypes: [.movie]) { result in
                Task {
                    do {
                        let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension(url.pathExtension)
                        try FileManager.default.copyItem(at: url, to: destination)
                        let asset = AVURLAsset(url: destination)
                        let seconds = try await asset.load(.duration).seconds
                        guard seconds.isFinite, seconds > 0 else { throw StudioError.message("Unsupported video duration.") }
                        if let old = source { try? FileManager.default.removeItem(at: old) }
                        source = destination; duration = seconds; start = 0; end = seconds; player = AVPlayer(url: destination)
                    } catch { self.error = error.localizedDescription }
                }
            }.onDisappear { player?.pause() }
    }
    private func export() async {
        guard let source else { return }
        busy = true; error = nil; defer { busy = false }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        defer { try? FileManager.default.removeItem(at: output) }
        do {
            let asset = AVURLAsset(url: source)
            guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPreset1920x1080), session.supportedFileTypes.contains(.mp4) else { throw StudioError.message("MP4 export is not supported for this asset.") }
            session.outputURL = output; session.outputFileType = .mp4
            session.timeRange = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600), end: CMTime(seconds: end, preferredTimescale: 600))
            await session.export()
            guard session.status == .completed else { throw session.error ?? StudioError.message("Video export failed.") }
            exported = try store.save(Data(contentsOf: output), name: "Trimmed video", ext: "mp4")
        } catch { self.error = error.localizedDescription }
    }
}
