import SwiftUI
import AVFoundation

@MainActor
final class AudioRecorder: NSObject, ObservableObject, AVAudioRecorderDelegate {
    @Published var recording = false
    @Published var error: String?
    @Published var file: URL?
    private var recorder: AVAudioRecorder?
    private var player: AVAudioPlayer?
    func start() async {
        let granted = await AVAudioApplication.requestRecordPermission()
        guard granted else { error = "Microphone access was denied. Enable it in iOS Settings."; return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try session.setActive(true)
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".m4a")
            recorder = try AVAudioRecorder(url: url, settings: [AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: 44100, AVNumberOfChannelsKey: 1, AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue])
            recorder?.delegate = self
            guard recorder?.record() == true else { throw StudioError.message("Could not start recording.") }
            recording = true; file = url
        } catch { self.error = error.localizedDescription }
    }
    func stop() { recorder?.stop(); recording = false; try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
    func play() {
        guard let file else { return }
        do { try AVAudioSession.sharedInstance().setCategory(.playback); try AVAudioSession.sharedInstance().setActive(true); player = try AVAudioPlayer(contentsOf: file); player?.play() } catch { self.error = error.localizedDescription }
    }
    func stopPlayback() { player?.stop(); try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
    nonisolated func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        Task { @MainActor in self.recording = false; self.error = error?.localizedDescription ?? "Recording failed." }
    }
}
struct AudioStudioView: View {
    @EnvironmentObject var store: ProjectStore
    @StateObject private var recorder = AudioRecorder()
    @State private var exported: URL?
    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: recorder.recording ? "waveform.circle.fill" : "mic.circle").font(.system(size: 100)).foregroundStyle(studioGradient).symbolEffect(.pulse, isActive: recorder.recording)
            Button(recorder.recording ? "Stop recording" : "Record audio") { if recorder.recording { recorder.stop() } else { Task { await recorder.start() } } }.buttonStyle(.borderedProminent)
            if recorder.file != nil && !recorder.recording {
                Button("Play") { recorder.play() }
                Button("Stop playback") { recorder.stopPlayback() }
                Button("Save to projects") {
                    do { if let url = recorder.file { exported = try store.save(Data(contentsOf: url), name: "Recording", ext: "m4a") } } catch { recorder.error = error.localizedDescription }
                }
            }
            if let exported { ShareLink(item: exported) }
            ErrorBanner(message: recorder.error)
        }.padding().navigationTitle("Audio Studio").onDisappear { recorder.stop(); recorder.stopPlayback() }
    }
}
