import SwiftUI

struct CalculatorView: View {
    @State private var first = ""
    @State private var second = ""
    @State private var operation = "+"
    @State private var degrees = true
    @State private var result = ""
    @State private var failed = false
    private let operations = ["+", "−", "×", "÷", "xʸ", "sin", "cos", "tan", "√", "ln", "log₁₀", "x²", "1/x", "n!"]
    private var binary: Bool { ["+", "−", "×", "÷", "xʸ"].contains(operation) }
    var body: some View {
        Form {
            Section("Scientific Calculator") {
                TextField("First number", text: $first).keyboardType(.numbersAndPunctuation)
                Picker("Operation", selection: $operation) { ForEach(operations, id: \.self) { Text($0).tag($0) } }
                if binary { TextField("Second number", text: $second).keyboardType(.numbersAndPunctuation) }
                if ["sin", "cos", "tan"].contains(operation) { Toggle("Use degrees", isOn: $degrees) }
                Button("Calculate") { calculate() }.buttonStyle(.borderedProminent)
            }
            Section("Result") {
                Text(result.isEmpty ? "—" : result).font(.title2.monospacedDigit()).foregroundStyle(failed ? .red : .primary).textSelection(.enabled)
                if !result.isEmpty && !failed {
                    Button("Copy result") { UIPasteboard.general.string = result }
                    Button("Use result as first number") { first = result }
                }
            }
            Button("Clear") { first = ""; second = ""; result = ""; failed = false }
            Text("Uses floating-point arithmetic. Input accepts decimal numbers, not expressions.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Scientific Calculator")
    }
    private func calculate() {
        guard let a = UtilityMath.number(first) else { reject(); return }
        do {
            let value = try UtilityMath.calculate(operation, a: a, b: UtilityMath.number(second), degrees: degrees)
            result = String(value); failed = false
        } catch { reject() }
    }
    private func reject() { result = String(localized: "Invalid input or undefined result."); failed = true }
}
