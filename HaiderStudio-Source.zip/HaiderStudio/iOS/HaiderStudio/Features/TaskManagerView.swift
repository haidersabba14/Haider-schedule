import SwiftUI

private struct StudioTaskItem: Identifiable, Codable {
    let id: UUID
    var title: String
    var done: Bool
    var important: Bool
}
struct TaskManagerView: View {
    @EnvironmentObject private var store: ProjectStore
    @AppStorage("studioTaskList") private var saved = "[]"
    @State private var tasks: [StudioTaskItem] = []
    @State private var draft = ""
    @State private var filter = "all"
    @State private var error: String?
    @State private var exported: URL?
    private var visible: [StudioTaskItem] {
        tasks.filter { filter == "all" || (filter == "active" && !$0.done) || (filter == "done" && $0.done) }
    }
    var body: some View {
        List {
            Section("New task") {
                TextField("Task title", text: $draft).onSubmit { add() }
                Button("Add task", systemImage: "plus.circle.fill") { add() }.disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || tasks.count >= 200)
                Text("Tasks stay on this device. Maximum 200 tasks.").font(.caption).foregroundStyle(.secondary)
            }
            Section {
                Picker("Show", selection: $filter) { Text("All").tag("all"); Text("Active").tag("active"); Text("Completed").tag("done") }.pickerStyle(.segmented)
                Text("\(tasks.filter(\.done).count) / \(tasks.count)").font(.caption.monospacedDigit())
                ForEach(visible) { task in
                    HStack {
                        Button { update(task.id) { $0.done.toggle() } } label: { Image(systemName: task.done ? "checkmark.circle.fill" : "circle").foregroundStyle(task.done ? .green : .secondary).font(.title2) }.buttonStyle(.borderless).accessibilityLabel("Toggle completed")
                        Text(task.title).strikethrough(task.done).foregroundStyle(task.done ? .secondary : .primary)
                        Spacer()
                        Button { update(task.id) { $0.important.toggle() } } label: { Image(systemName: task.important ? "flag.fill" : "flag").foregroundStyle(task.important ? .orange : .secondary) }.buttonStyle(.borderless).accessibilityLabel("Toggle priority")
                    }.swipeActions { Button("Delete", role: .destructive) { tasks.removeAll { $0.id == task.id }; persist() } }
                }
            }
            Section {
                Button("Clear completed", role: .destructive) { tasks.removeAll(where: \.done); persist() }.disabled(!tasks.contains(where: \.done))
                Button("Export tasks as JSON") {
                    do { exported = try store.save(JSONEncoder().encode(tasks), name: "Tasks", ext: "json") } catch { self.error = error.localizedDescription }
                }
                if let exported { ShareLink(item: exported) }
            }
            ErrorBanner(message: error)
        }.navigationTitle("Task Manager").onAppear { load() }
    }
    private func load() {
        do { tasks = try JSONDecoder().decode([StudioTaskItem].self, from: Data(saved.utf8)) }
        catch { self.error = error.localizedDescription }
    }
    private func add() {
        let name = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, tasks.count < 200 else { return }
        tasks.insert(StudioTaskItem(id: UUID(), title: String(name.prefix(500)), done: false, important: false), at: 0)
        draft = ""; persist()
    }
    private func update(_ id: UUID, change: (inout StudioTaskItem) -> Void) {
        guard let index = tasks.firstIndex(where: { $0.id == id }) else { return }
        change(&tasks[index]); persist()
    }
    private func persist() {
        do { saved = String(decoding: try JSONEncoder().encode(tasks), as: UTF8.self) }
        catch { self.error = error.localizedDescription }
    }
}
