import SwiftUI
import CoreImage.CIFilterBuiltins
import Security

struct ToolsView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var qrText = "https://example.com"
    @State private var qr: UIImage?
    @State private var password = ""
    @State private var length = 24
    @State private var note = ""
    @State private var color = Color.purple
    @State private var exported: URL?
    @State private var error: String?
    var body: some View {
        Form {
            Section("QR Generator") {
                TextField("Text or URL", text: $qrText).textInputAutocapitalization(.never)
                Button("Generate QR") {
                    let filter = CIFilter.qrCodeGenerator(); filter.message = Data(qrText.utf8)
                    if let output = filter.outputImage, let cg = CIContext().createCGImage(output.transformed(by: CGAffineTransform(scaleX: 10, y: 10)), from: output.extent.applying(CGAffineTransform(scaleX: 10, y: 10))) { qr = UIImage(cgImage: cg) }
                }
                if let qr {
                    Image(uiImage: qr).interpolation(.none).resizable().scaledToFit().frame(height: 220).accessibilityLabel("Generated QR code")
                    Button("Save QR") { do { if let data = qr.pngData() { exported = try store.save(data, name: "QR code", ext: "png") } } catch { self.error = error.localizedDescription } }
                }
            }
            Section("Password Generator") {
                Stepper("Length: \(length)", value: $length, in: 12...128)
                Button("Generate secure password") {
                    do { password = try securePassword(length: length) } catch { self.error = error.localizedDescription }
                }
                if !password.isEmpty { Text(password).font(.system(.body, design: .monospaced)).textSelection(.enabled).privacySensitive() }
            }
            Section("Color Picker") {
                ColorPicker("Color", selection: $color, supportsOpacity: false)
                Text(hexColor).textSelection(.enabled)
            }
            Section("Notes / Markdown") {
                TextEditor(text: $note).frame(minHeight: 160)
                Button("Save note") { do { exported = try store.save(Data(note.utf8), name: "Note", ext: "md") } catch { self.error = error.localizedDescription } }
                if !note.isEmpty { Text(.init(note)) }
            }
            if let exported { ShareLink(item: exported) }
            ErrorBanner(message: error)
        }.navigationTitle("Advanced Tools")
    }
    private var hexColor: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(color).getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
    private func securePassword(length: Int) throws -> String {
        let alphabet = Array("ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*+-=?")
        let bound = 256 - 256 % alphabet.count
        var output = ""
        while output.count < length {
            var byte: UInt8 = 0
            guard SecRandomCopyBytes(kSecRandomDefault, 1, &byte) == errSecSuccess else { throw StudioError.message("Secure random generator failed.") }
            if Int(byte) < bound { output.append(alphabet[Int(byte) % alphabet.count]) }
        }
        return output
    }
}
