import SwiftUI

struct AIView: View {
    @EnvironmentObject var store: ProjectStore
    @AppStorage("backendURL") private var backendURL = ""
    @State private var prompt = ""
    @State private var result = ""
    @State private var mode = "chat"
    @State private var busy = false
    @State private var consent = false
    @State private var error: String?
    @State private var requestTask: Task<Void, Never>?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Label("Real AI · Requires your deployed gateway", systemImage: "sparkles").font(.headline)
                Text("Text assistance for writing, translation and code.").font(.caption).foregroundStyle(.secondary)
                Picker("Task", selection: $mode) {
                    Text("Chat").tag("chat"); Text("Writing").tag("write"); Text("Summarize").tag("summarize"); Text("Translate").tag("translate"); Text("Correct text").tag("correct"); Text("Write code").tag("code"); Text("Explain code").tag("explain")
                }
                TextEditor(text: $prompt).frame(height: 180).padding(8).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 15))
                Text("Translation: include the target language in your prompt. Do not send sensitive information.").font(.caption).foregroundStyle(.secondary)
                Button("Send to AI provider") { consent = true }.buttonStyle(.borderedProminent).disabled(busy || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if busy { ProgressView(); Button("Cancel") { requestTask?.cancel() } }
                if !result.isEmpty {
                    Text(result).textSelection(.enabled)
                    Button("Save response") { do { _ = try store.save(Data(result.utf8), name: "AI response", ext: "md") } catch { self.error = error.localizedDescription } }
                }
                ErrorBanner(message: error)
            }.padding()
        }.navigationTitle("AI Studio")
            .alert("Send text to cloud AI?", isPresented: $consent) {
                Button("Cancel", role: .cancel) {}
                Button("Send") { requestTask = Task { await send() } }
            } message: { Text("Your entered text will be sent to the configured Cloudflare gateway and its AI provider. Provider charges may apply.") }
            .onDisappear { requestTask?.cancel() }
    }
    private func send() async {
        guard let base = URL(string: backendURL), base.scheme == "https", base.host != nil, base.user == nil, base.password == nil else { error = "Set a valid HTTPS Worker URL in Settings first."; return }
        busy = true; error = nil; defer { busy = false }
        do {
            var request = URLRequest(url: base.appendingPathComponent("v1/ai"))
            request.httpMethod = "POST"; request.timeoutInterval = 90
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(AIInput(mode: mode, prompt: prompt))
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else { throw StudioError.message("Invalid gateway response.") }
            guard http.statusCode == 200 else {
                let message = (try? JSONDecoder().decode(AIFailure.self, from: data))?.error ?? "Gateway error (\(http.statusCode))."
                throw StudioError.message(message)
            }
            try Task.checkCancellation()
            result = try JSONDecoder().decode(AIOutput.self, from: data).text
        } catch is CancellationError { error = "Cancelled. The provider may already have processed the request." }
        catch { self.error = error.localizedDescription }
    }
}
private struct AIInput: Encodable { let mode: String; let prompt: String }
private struct AIOutput: Decodable { let text: String }
private struct AIFailure: Decodable { let error: String }
