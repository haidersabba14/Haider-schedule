import SwiftUI
import CryptoKit

struct TextLabView: View {
    @EnvironmentObject private var store: ProjectStore
    @State private var input = ""
    @State private var find = ""
    @State private var replacement = ""
    @State private var output = ""
    @State private var error: String?
    @State private var exported: URL?
    private var words: Int { input.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count }
    var body: some View {
        Form {
            Section("Text statistics") {
                LabeledContent("Characters", value: input.count.formatted())
                LabeledContent("Words", value: words.formatted())
                LabeledContent("Lines", value: (input.isEmpty ? 0 : input.components(separatedBy: .newlines).count).formatted())
                LabeledContent("UTF-8 bytes", value: input.utf8.count.formatted())
            }
            Section("Input text") { TextEditor(text: $input).frame(minHeight: 170).autocorrectionDisabled().textInputAutocapitalization(.never) }
            Section("Text actions") {
                Button("UPPERCASE") { output = input.uppercased(); error = nil }
                Button("lowercase") { output = input.lowercased(); error = nil }
                Button("Trim spaces") { output = input.trimmingCharacters(in: .whitespacesAndNewlines); error = nil }
                Button("Remove repeated spaces") { output = input.replacingOccurrences(of: "[\\t ]+", with: " ", options: .regularExpression); error = nil }
                Button("Remove duplicate lines") {
                    var seen = Set<String>()
                    output = input.components(separatedBy: .newlines).filter { seen.insert($0).inserted }.joined(separator: "\n"); error = nil
                }
                TextField("Find", text: $find).autocorrectionDisabled()
                TextField("Replace", text: $replacement).autocorrectionDisabled()
                Button("Replace all") { output = input.replacingOccurrences(of: find, with: replacement); error = nil }.disabled(find.isEmpty)
            }
            Section("Encoding and checksums") {
                Button("Encode Base64") { output = Data(input.utf8).base64EncodedString(); error = nil }
                Button("Decode Base64") {
                    guard let data = Data(base64Encoded: input.trimmingCharacters(in: .whitespacesAndNewlines)), let text = String(data: data, encoding: .utf8) else { error = "Invalid Base64 or non-UTF-8 content."; return }
                    output = text; error = nil
                }
                Button("URL encode") { output = input.addingPercentEncoding(withAllowedCharacters: CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")) ?? ""; error = nil }
                Button("URL decode") {
                    guard let text = input.removingPercentEncoding else { error = "Invalid URL encoding."; return }
                    output = text; error = nil
                }
                Button("SHA-256 checksum") { output = SHA256.hash(data: Data(input.utf8)).map { String(format: "%02x", $0) }.joined(); error = nil }
            }
            Section("JSON tools") {
                Button("Format JSON") { json(pretty: true) }
                Button("Minify JSON") { json(pretty: false) }
            }
            Section("Result") {
                Text(output.isEmpty ? "—" : output).font(.system(.body, design: .monospaced)).textSelection(.enabled)
                Button("Use result as input") { input = output }.disabled(output.isEmpty)
                Button("Copy result") { UIPasteboard.general.string = output }.disabled(output.isEmpty)
                Button("Save result") {
                    do { exported = try store.save(Data(output.utf8), name: "Text result", ext: "txt") } catch { self.error = error.localizedDescription }
                }.disabled(output.isEmpty)
                if let exported { ShareLink(item: exported) }
            }
            ErrorBanner(message: error)
        }.navigationTitle("Text Lab")
    }
    private func json(pretty: Bool) {
        do {
            let object = try JSONSerialization.jsonObject(with: Data(input.utf8), options: [.fragmentsAllowed])
            var options: JSONSerialization.WritingOptions = [.sortedKeys, .fragmentsAllowed]
            if pretty { options.insert(.prettyPrinted) }
            output = String(decoding: try JSONSerialization.data(withJSONObject: object, options: options), as: UTF8.self); error = nil
        } catch { self.error = error.localizedDescription }
    }
}
