import SwiftUI
import QuickLook

struct ProjectDetailView: View {
    @EnvironmentObject private var store: ProjectStore
    let item: StudioProject
    var body: some View {
        VStack(spacing: 0) {
            LocalFilePreview(url: store.url(item))
            ShareLink(item: store.url(item)) { Label("Export file", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding() }.buttonStyle(.borderedProminent).padding()
        }.navigationTitle(item.name).navigationBarTitleDisplayMode(.inline)
    }
}
struct LocalFilePreview: UIViewControllerRepresentable {
    let url: URL
    func makeCoordinator() -> Coordinator { Coordinator(url: url) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController(); controller.dataSource = context.coordinator; return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {
        if context.coordinator.url != url { context.coordinator.url = url; controller.reloadData() }
    }
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        var url: URL
        init(url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}
