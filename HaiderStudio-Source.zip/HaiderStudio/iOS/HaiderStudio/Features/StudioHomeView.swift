import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: ProjectStore
    @Environment(\.locale) private var locale
    @Environment(\.dynamicTypeSize) private var typeSize
    @AppStorage("studioAccent") private var accent = "aurora"
    @AppStorage("homeFavorites") private var favorites = "photo,design,video"
    @AppStorage("homeOrder") private var order = "photo,design,video,audio,pdf,palette,code,tools,game"
    @State private var search = ""
    @State private var customizing = false
    private var palette: StudioAccent { StudioAccent(rawValue: accent) ?? .aurora }
    private var ordered: [StudioTool] { StudioTool.ordered(order) }
    private var filtered: [StudioTool] {
        ordered.filter { tool in
            search.isEmpty || tool.title.localizedCaseInsensitiveContains(search) || tool.subtitle.localizedCaseInsensitiveContains(search)
            || localized(tool.title).localizedCaseInsensitiveContains(search) || localized(tool.subtitle).localizedCaseInsensitiveContains(search)
        }
    }
    private var pinned: [StudioTool] { ordered.filter { favorites.split(separator: ",").contains(Substring($0.rawValue)) } }
    private var columns: [GridItem] { [GridItem(.adaptive(minimum: typeSize.isAccessibilitySize ? 280 : 155), spacing: 14)] }
    private func localized(_ key: String) -> String {
        let path = Bundle.main.path(forResource: locale.language.languageCode?.identifier ?? "en", ofType: "lproj")
        return (path.flatMap(Bundle.init(path:)) ?? .main).localizedString(forKey: key, value: key, table: nil)
    }
    var body: some View {
        ZStack {
            StudioBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    header
                    if search.isEmpty {
                        hero
                        if !pinned.isEmpty {
                            StudioSectionHeading(title: "Your favorites", symbol: "star.fill")
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(pinned) { tool in
                                        NavigationLink { tool.destination } label: {
                                            HStack(spacing: 10) {
                                                Image(systemName: tool.icon).foregroundStyle(palette.gradient)
                                                Text(LocalizedStringKey(tool.title)).font(.subheadline.weight(.semibold))
                                            }.padding(.horizontal, 18).padding(.vertical, 15)
                                                .background(.thinMaterial, in: Capsule())
                                                .overlay(Capsule().stroke(.purple.opacity(0.22)))
                                        }.buttonStyle(StudioPressStyle())
                                    }
                                }.padding(.vertical, 2)
                            }
                        }
                    }
                    HStack {
                        StudioSectionHeading(title: "Creative studios", symbol: "square.grid.2x2.fill")
                        Button { customizing = true } label: { Image(systemName: "slider.horizontal.3").padding(10).background(.thinMaterial, in: Circle()) }
                            .accessibilityLabel("Customize Home")
                    }
                    if filtered.isEmpty { ContentUnavailableView.search(text: search) }
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(filtered) { tool in
                            NavigationLink { tool.destination } label: { toolCard(tool) }.buttonStyle(StudioPressStyle())
                        }
                    }
                    if search.isEmpty && !store.items.isEmpty {
                        HStack {
                            StudioSectionHeading(title: "Recently saved", symbol: "clock.arrow.circlepath")
                            NavigationLink("See all") { ProjectsView() }.font(.caption.weight(.semibold))
                        }
                        ForEach(Array(store.items.prefix(3))) { item in
                            NavigationLink { ProjectDetailView(item: item) } label: {
                                StudioCard {
                                    HStack(spacing: 14) {
                                        Image(systemName: "doc.fill").font(.title3).foregroundStyle(palette.gradient)
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(item.name).font(.subheadline.weight(.semibold)).lineLimit(2)
                                            Text(item.created, style: .relative).font(.caption).foregroundStyle(.secondary)
                                        }
                                        Spacer(); Text(item.filename.components(separatedBy: ".").last?.uppercased() ?? "FILE").font(.caption2.monospaced()).foregroundStyle(.secondary)
                                    }
                                }
                            }.buttonStyle(StudioPressStyle())
                        }
                    }
                    Label("Made for your next idea", systemImage: "sparkle").font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.bottom, 12)
                }.padding(20).frame(maxWidth: 900).frame(maxWidth: .infinity)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, prompt: "Search tools")
        .sheet(isPresented: $customizing) { HomeCustomizationView() }
    }
    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text("HAIDER STUDIO").font(.system(.headline, design: .rounded).weight(.black)).tracking(2)
                Text("Your creative universe").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Label("Online", systemImage: "circle.fill").font(.caption2.weight(.semibold)).foregroundStyle(.green)
                .padding(.horizontal, 12).padding(.vertical, 8).background(.green.opacity(0.09), in: Capsule())
        }
    }
    private var hero: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .center, spacing: 14) {
                Image("BrandLogo").resizable().scaledToFit().frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 22)).overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.1)))
                    .shadow(color: palette.colors[0].opacity(0.35), radius: 25)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 10) {
                    Text("ULTIMATE").font(.caption2.weight(.black)).tracking(3).foregroundStyle(palette.gradient)
                    Text("Imagine. Create. Shine.").font(.system(.title, design: .rounded).weight(.bold)).fixedSize(horizontal: false, vertical: true)
                }
            }
            Text("Your ideas deserve a beautiful workspace.").font(.subheadline).foregroundStyle(.secondary)
            NavigationLink { DesignStudioView() } label: {
                HStack { Text("Start creating").font(.headline); Spacer(); Image(systemName: "arrow.forward") }
                    .foregroundStyle(.white).padding(17).background(palette.gradient, in: RoundedRectangle(cornerRadius: 17))
            }.buttonStyle(StudioPressStyle())
            HStack(spacing: 16) {
                Label("Local projects", systemImage: "externaldrive.fill")
                Text(store.items.count.formatted()).monospacedDigit().fontWeight(.bold)
                Spacer()
                Image(systemName: "lock.shield").foregroundStyle(palette.colors[2])
            }.font(.caption).foregroundStyle(.secondary)
        }
        .padding(24)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(palette.gradient.opacity(0.5), lineWidth: 1))
        .shadow(color: palette.colors[0].opacity(0.1), radius: 35, y: 10)
    }
    private func toolCard(_ tool: StudioTool) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Image(systemName: tool.icon).font(.title2.weight(.medium)).foregroundStyle(palette.gradient)
                    .frame(width: 49, height: 49).background(palette.colors[0].opacity(0.1), in: RoundedRectangle(cornerRadius: 15))
                Spacer()
                if tool == .palette { Text("NEW").font(.caption2.weight(.black)).foregroundStyle(.cyan) }
                else { Image(systemName: "arrow.up.forward").font(.caption).foregroundStyle(.tertiary).accessibilityHidden(true) }
            }
            VStack(alignment: .leading, spacing: 7) {
                Text(LocalizedStringKey(tool.title)).font(.headline).foregroundStyle(.primary)
                Text(LocalizedStringKey(tool.subtitle)).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(18).frame(maxWidth: .infinity, minHeight: typeSize.isAccessibilitySize ? 230 : 185, alignment: .topLeading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(LinearGradient(colors: [.white.opacity(0.23), palette.colors[0].opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing)))
        .contextMenu {
            Button(LocalizedStringKey(favorites.split(separator: ",").contains(Substring(tool.rawValue)) ? "Remove favorite" : "Add favorite"), systemImage: "star") { toggleFavorite(tool) }
        }
    }
    private func toggleFavorite(_ tool: StudioTool) {
        var values = favorites.split(separator: ",").map(String.init)
        if values.contains(tool.rawValue) { values.removeAll { $0 == tool.rawValue } } else { values.append(tool.rawValue) }
        favorites = values.joined(separator: ",")
    }
}

struct HomeCustomizationView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("studioAccent") private var accent = "aurora"
    @AppStorage("homeFavorites") private var favorites = "photo,design,video"
    @AppStorage("homeOrder") private var order = "photo,design,video,audio,pdf,palette,code,tools,game"
    var body: some View {
        NavigationStack {
            List {
                Section("Studio lighting") {
                    Picker("Color theme", selection: $accent) {
                        ForEach(StudioAccent.allCases) { style in Text(LocalizedStringKey(style.title)).tag(style.rawValue) }
                    }
                }
                Section {
                    ForEach(StudioTool.ordered(order)) { tool in
                        HStack {
                            Label(LocalizedStringKey(tool.title), systemImage: tool.icon)
                            Spacer()
                            Button {
                                var values = favorites.split(separator: ",").map(String.init)
                                if values.contains(tool.rawValue) { values.removeAll { $0 == tool.rawValue } } else { values.append(tool.rawValue) }
                                favorites = values.joined(separator: ",")
                            } label: { Image(systemName: favorites.split(separator: ",").contains(Substring(tool.rawValue)) ? "star.fill" : "star").foregroundStyle(.purple).padding(8) }
                                .buttonStyle(.borderless).accessibilityLabel("Toggle favorite")
                        }
                    }.onMove { indices, destination in
                        var values = StudioTool.ordered(order)
                        values.move(fromOffsets: indices, toOffset: destination)
                        order = values.map(\.rawValue).joined(separator: ",")
                    }
                } header: { Text("Your tool order") } footer: { Text("Drag handles to reorder. Tap stars to pin favorites. Changes are saved on this device.") }
                Button("Restore Home defaults") { order = "photo,design,video,audio,pdf,palette,code,tools,game"; favorites = "photo,design,video"; accent = "aurora" }
            }
            .environment(\.editMode, .constant(.active))
            .navigationTitle("Customize Home")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
