import SwiftUI
import PDFKit
import PhotosUI
import UniformTypeIdentifiers

struct PDFStudioView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var photos: [PhotosPickerItem] = []
    @State private var document: PDFDocument?
    @State private var importing = false
    @State private var exported: URL?
    @State private var text = ""
    @State private var page = 1
    @State private var error: String?
    var body: some View {
        VStack {
            NavigationLink("Text to PDF") { TextToPDFView() }.padding(.top)
            HStack {
                PhotosPicker(selection: $photos, maxSelectionCount: 40, matching: .images) { Label("Images to PDF", systemImage: "photo.stack") }
                Button("Import / merge PDFs") { importing = true }
            }.padding()
            if let document {
                PDFPreview(document: document).frame(minHeight: 240)
                Text("\(document.pageCount) pages")
                Stepper("Page \(page)", value: $page, in: 1...max(1, document.pageCount))
                Menu("Page tools") {
                    Button("Rotate page 90°") {
                        edit(document) { pdf in
                            if let target = pdf.page(at: page - 1) { target.rotation = (target.rotation + 90) % 360 }
                        }
                    }
                    Button("Move page earlier") {
                        guard page > 1 else { return }
                        if edit(document, change: { $0.exchangePage(at: page - 1, withPageAt: page - 2) }) { page -= 1 }
                    }.disabled(page <= 1)
                    Button("Move page later") {
                        guard page < document.pageCount else { return }
                        if edit(document, change: { $0.exchangePage(at: page - 1, withPageAt: page) }) { page += 1 }
                    }.disabled(page >= document.pageCount)
                    Button("Reverse page order") {
                        edit(document) { pdf in
                            for index in 0..<(pdf.pageCount / 2) { pdf.exchangePage(at: index, withPageAt: pdf.pageCount - index - 1) }
                        }
                    }
                }

                HStack {
                    Button("Extract page") {
                        guard let source = document.page(at: page - 1), let copy = source.copy() as? PDFPage else { return }
                        let result = PDFDocument(); result.insert(copy, at: 0); save(result)
                    }
                    Button("Delete page", role: .destructive) {
                        guard document.pageCount > 1 else { return }
                        let copy = PDFDocument(data: document.dataRepresentation() ?? Data())
                        copy?.removePage(at: page - 1); self.document = copy; page = min(page, copy?.pageCount ?? 1)
                    }
                }
                HStack { Button("Extract text") { text = document.string ?? "No text layer. OCR is available in Photo Studio." }; Button("Save PDF") { save(document) } }
            } else { ContentUnavailableView("Import images or PDF files", systemImage: "doc.richtext") }
            if !text.isEmpty { ScrollView { Text(text).textSelection(.enabled) }.frame(maxHeight: 130) }
            if let exported { ShareLink(item: exported) }
            ErrorBanner(message: error)
        }.padding().navigationTitle("PDF Studio")
            .fileImporter(isPresented: $importing, allowedContentTypes: [.pdf], allowsMultipleSelection: true) { result in
                do {
                    let merged = document?.copy() as? PDFDocument ?? PDFDocument()
                    for url in try result.get() {
                        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                        guard let pdf = PDFDocument(url: url), !pdf.isLocked else { throw StudioError.message("Cannot read this PDF. Unlock encrypted files first.") }
                        for index in 0..<pdf.pageCount { if let page = pdf.page(at: index)?.copy() as? PDFPage { merged.insert(page, at: merged.pageCount) } }
                    }
                    document = merged
                } catch { self.error = error.localizedDescription }
            }
            .onChange(of: photos) { _, items in
                Task {
                    let pdf = PDFDocument()
                    do {
                        for item in items {
                            if let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data), let page = PDFPage(image: image) { pdf.insert(page, at: pdf.pageCount) }
                        }
                        document = pdf; page = 1
                    } catch { self.error = error.localizedDescription }
                }
            }
    }
    @discardableResult
    private func edit(_ source: PDFDocument, change: (PDFDocument) -> Void) -> Bool {
        guard let data = source.dataRepresentation(), let copy = PDFDocument(data: data) else { error = "Cannot edit this PDF."; return false }
        change(copy); document = copy; exported = nil; return true
    }
    private func save(_ pdf: PDFDocument) {
        do { guard let data = pdf.dataRepresentation() else { throw StudioError.message("PDF export failed.") }; exported = try store.save(data, name: "Document", ext: "pdf") } catch { self.error = error.localizedDescription }
    }
}
struct PDFPreview: UIViewRepresentable {
    let document: PDFDocument
    func makeUIView(context: Context) -> PDFView { let v = PDFView(); v.autoScales = true; return v }
    func updateUIView(_ view: PDFView, context: Context) { view.document = document }
}
