import SwiftUI

private enum ConversionGroup: String, CaseIterable, Identifiable {
    case length, mass, temperature, area, volume, time, data
    var id: String { rawValue }
    var title: String { switch self { case .length: "Length"; case .mass: "Mass"; case .temperature: "Temperature"; case .area: "Area"; case .volume: "Volume"; case .time: "Time"; case .data: "Digital storage" } }
    var units: [ConversionUnit] {
        switch self {
        case .length: [.init("mm", 0.001), .init("cm", 0.01), .init("m", 1), .init("km", 1000), .init("in", 0.0254), .init("ft", 0.3048), .init("mi", 1609.344)]
        case .mass: [.init("mg", 0.000001), .init("g", 0.001), .init("kg", 1), .init("lb", 0.45359237), .init("oz", 0.028349523125)]
        case .temperature: [.init("°C", 1), .init("°F", 5.0 / 9, offset: -32 * 5.0 / 9), .init("K", 1, offset: -273.15)]
        case .area: [.init("m²", 1), .init("km²", 1_000_000), .init("ft²", 0.09290304), .init("ha", 10_000), .init("acre", 4046.8564224)]
        case .volume: [.init("mL", 0.001), .init("L", 1), .init("m³", 1000), .init("US gal", 3.785411784), .init("US fl oz", 0.0295735295625)]
        case .time: [.init("s", 1), .init("min", 60), .init("h", 3600), .init("day", 86400), .init("week", 604800)]
        case .data: [.init("B", 1), .init("kB", 1000), .init("MB", 1_000_000), .init("GB", 1_000_000_000), .init("KiB", 1024), .init("MiB", 1_048_576), .init("GiB", 1_073_741_824)]
        }
    }
}
private struct ConversionUnit: Identifiable {
    let id: String
    let factor: Double
    let offset: Double
    init(_ id: String, _ factor: Double, offset: Double = 0) { self.id = id; self.factor = factor; self.offset = offset }
}
struct ConverterView: View {
    @State private var group = ConversionGroup.length
    @State private var value = "1"
    @State private var from = 0
    @State private var to = 1
    private var result: Double? {
        let number = UtilityMath.number(value)
        guard let number, number.isFinite, group.units.indices.contains(from), group.units.indices.contains(to) else { return nil }
        let source = group.units[from], target = group.units[to]
        return try? UtilityMath.convert(number, sourceFactor: source.factor, sourceOffset: source.offset,
                                        targetFactor: target.factor, targetOffset: target.offset, temperature: group == .temperature)
    }
    var body: some View {
        Form {
            Picker("Category", selection: $group) { ForEach(ConversionGroup.allCases) { Text(LocalizedStringKey($0.title)).tag($0) } }
            Section("Value") { TextField("Number", text: $value).keyboardType(.numbersAndPunctuation) }
            Section("Units") {
                Picker("From", selection: $from) { ForEach(group.units.indices, id: \.self) { Text(group.units[$0].id).tag($0) } }
                Picker("To", selection: $to) { ForEach(group.units.indices, id: \.self) { Text(group.units[$0].id).tag($0) } }
                Button("Swap units", systemImage: "arrow.up.arrow.down") { let old = from; from = to; to = old }
            }
            Section("Result") {
                if let result {
                    Text(result.formatted(.number.precision(.significantDigits(1...12))) + " " + group.units[to].id).font(.title2.monospacedDigit()).textSelection(.enabled)
                    Button("Copy result") { UIPasteboard.general.string = String(result) + " " + group.units[to].id }
                } else { Text("Enter a valid finite number. Temperature must be above absolute zero.").foregroundStyle(.secondary) }
            }
            Text("Storage: kB/MB/GB use 1000; KiB/MiB/GiB use 1024. Volume units marked US use the US definition.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Unit Converter").onChange(of: group) { from = 0; to = 1 }
    }
}
