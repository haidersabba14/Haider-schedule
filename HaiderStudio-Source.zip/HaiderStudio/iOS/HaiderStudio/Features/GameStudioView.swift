import SwiftUI
import SpriteKit

final class StudioGameScene: SKScene {
    private var hero = SKShapeNode(circleOfRadius: 22)
    private var goal = SKShapeNode(rectOf: CGSize(width: 44, height: 44), cornerRadius: 8)
    private var scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private var score = 0
    override func didMove(to view: SKView) {
        backgroundColor = .black
        hero.fillColor = .cyan; hero.strokeColor = .blue; hero.glowWidth = 10
        hero.position = CGPoint(x: size.width / 2, y: size.height / 2)
        goal.fillColor = .purple; goal.strokeColor = .white
        scoreLabel.fontSize = 24; scoreLabel.position = CGPoint(x: size.width / 2, y: size.height - 45)
        addChild(hero); addChild(goal); addChild(scoreLabel); placeGoal()
    }
    private func placeGoal() {
        goal.position = CGPoint(x: CGFloat.random(in: 35...max(36, size.width - 35)), y: CGFloat.random(in: 55...max(56, size.height - 95)))
        scoreLabel.text = "★ \(score)"
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: self) else { return }
        hero.removeAllActions()
        hero.run(.move(to: point, duration: 0.25))
    }
    override func update(_ currentTime: TimeInterval) {
        if hypot(hero.position.x - goal.position.x, hero.position.y - goal.position.y) < 42 { score += 1; placeGoal() }
    }
}
struct GameStudioView: View {
    @State private var scene = StudioGameScene(size: CGSize(width: 360, height: 560))
    var body: some View {
        VStack {
            Text("Playable prototype · Tap to collect purple squares.").padding()
            SpriteView(scene: scene).aspectRatio(360.0 / 560, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 20))
            Text("A complete game project editor is planned and is not included in this build.").font(.caption).foregroundStyle(.secondary).padding()
        }.navigationTitle("Game Studio")
    }
}
