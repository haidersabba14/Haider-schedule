import SwiftUI
import PhotosUI
import CoreImage.CIFilterBuiltins
import UniformTypeIdentifiers
import Vision

struct PhotoEditorView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var selection: PhotosPickerItem?
    @State private var original: UIImage?
    @State private var preview: UIImage?
    @State private var brightness = 0.0
    @State private var contrast = 1.0
    @State private var saturation = 1.0
    @State private var rotation = 0.0
    @State private var width = 1080.0
    @State private var pixelate = false
    @State private var showOriginal = false
    @State private var format = "png"
    @State private var exported: URL?
    @State private var error: String?
    @State private var ocr = ""
    private let context = CIContext()
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                PhotosPicker(selection: $selection, matching: .images) { Label("Choose photo", systemImage: "photo.badge.plus") }
                if let image = showOriginal ? original : preview {
                    Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 340)
                    Toggle("Show original", isOn: $showOriginal)
                    Group {
                        Text("Brightness"); Slider(value: $brightness, in: -1...1)
                        Text("Contrast"); Slider(value: $contrast, in: 0...3)
                        Text("Saturation"); Slider(value: $saturation, in: 0...2)
                        Text("Export width: \(Int(width)) px"); Slider(value: $width, in: 128...4096, step: 1)
                        Toggle("Pixel Art", isOn: $pixelate)
                    }
                    HStack {
                        Button("Rotate", systemImage: "rotate.right") { rotation += .pi / 2; render() }
                        Button("Reset") { brightness = 0; contrast = 1; saturation = 1; rotation = 0; pixelate = false; render() }
                    }
                    Picker("Format", selection: $format) { Text("PNG").tag("png"); Text("JPEG").tag("jpg") }.pickerStyle(.segmented)
                    Button("Save to projects", systemImage: "square.and.arrow.down") { save() }.buttonStyle(.borderedProminent)
                    Button("Extract text (OCR)") { recognize() }
                    if !ocr.isEmpty { Text(ocr).textSelection(.enabled) }
                }
                if let exported { ShareLink(item: exported) }
                ErrorBanner(message: error)
            }.padding()
        }.navigationTitle("Photo Studio")
            .onChange(of: selection) { _, item in
                Task {
                    do {
                        guard let data = try await item?.loadTransferable(type: Data.self), let image = UIImage(data: data) else { return }
                        // Normalize orientation and cap working resolution before Core Image processing.
                        let scale = min(1, 4096 / max(image.size.width, image.size.height))
                        let size = CGSize(width: image.size.width * scale, height: image.size.height * scale)
                        let renderer = UIGraphicsImageRenderer(size: size, format: renderFormat)
                        original = renderer.image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
                        render()
                    } catch { self.error = error.localizedDescription }
                }
            }
            .onChange(of: brightness) { render() }.onChange(of: contrast) { render() }.onChange(of: saturation) { render() }.onChange(of: pixelate) { render() }
    }
    private var renderFormat: UIGraphicsImageRendererFormat { let f = UIGraphicsImageRendererFormat(); f.scale = 1; return f }
    private func render() {
        guard let original, let input = CIImage(image: original) else { return }
        let filter = CIFilter.colorControls(); filter.inputImage = input; filter.brightness = Float(brightness); filter.contrast = Float(contrast); filter.saturation = Float(saturation)
        guard var output = filter.outputImage else { return }
        if pixelate { let p = CIFilter.pixellate(); p.inputImage = output; p.scale = 18; if let result = p.outputImage { output = result.cropped(to: output.extent) } }
        output = output.transformed(by: CGAffineTransform(rotationAngle: rotation))
        if let cg = context.createCGImage(output, from: output.extent) { preview = UIImage(cgImage: cg) }
    }
    private func save() {
        do {
            guard let preview else { return }
            let size = CGSize(width: width, height: width * preview.size.height / preview.size.width)
            let output = UIGraphicsImageRenderer(size: size, format: renderFormat).image { _ in preview.draw(in: CGRect(origin: .zero, size: size)) }
            guard let data = format == "png" ? output.pngData() : output.jpegData(compressionQuality: 0.9) else { throw StudioError.message("Encoding failed.") }
            exported = try store.save(data, name: "Photo", ext: format)
        } catch { self.error = error.localizedDescription }
    }
    private func recognize() {
        guard let cg = original?.cgImage else { return }
        do {
            let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.automaticallyDetectsLanguage = true
            try VNImageRequestHandler(cgImage: cg).perform([request])
            ocr = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            if ocr.isEmpty { ocr = "No text detected." }
        } catch { self.error = error.localizedDescription }
    }
}
