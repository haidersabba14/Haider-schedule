import SwiftUI
import PhotosUI
import ImageIO
import CoreGraphics

struct ExtractedColor: Identifiable, Codable, Sendable {
    var id: String { hex }
    let red: Int
    let green: Int
    let blue: Int
    var hex: String { String(format: "#%02X%02X%02X", red, green, blue) }
    var color: Color { Color(red: Double(red) / 255, green: Double(green) / 255, blue: Double(blue) / 255) }
}

actor PaletteExtractor {
    func extract(_ data: Data) throws -> [ExtractedColor] {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 128
              ] as CFDictionary) else { throw StudioError.message("Unable to decode this image.") }
        let width = image.width, height = image.height
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        return try bytes.withUnsafeMutableBytes { buffer in
            guard let space = CGColorSpace(name: CGColorSpace.sRGB), let context = CGContext(
                data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                bytesPerRow: width * 4, space: space,
                bitmapInfo: CGBitmapInfo.byteOrder32Big.rawValue | CGImageAlphaInfo.premultipliedLast.rawValue
            ) else { throw StudioError.message("Unable to read image colors.") }
            context.draw(image, in: CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))
            let pixels = buffer.bindMemory(to: UInt8.self)
            var buckets: [Int: (count: Int, r: Int, g: Int, b: Int)] = [:]
            for offset in stride(from: 0, to: pixels.count, by: 4) {
                let alpha = Int(pixels[offset + 3])
                guard alpha >= 128 else { continue }
                let r = min(255, Int(pixels[offset]) * 255 / alpha)
                let g = min(255, Int(pixels[offset + 1]) * 255 / alpha)
                let b = min(255, Int(pixels[offset + 2]) * 255 / alpha)
                let key = (r >> 4) << 8 | (g >> 4) << 4 | (b >> 4)
                let old = buckets[key] ?? (count: 0, r: 0, g: 0, b: 0)
                buckets[key] = (old.count + 1, old.r + r, old.g + g, old.b + b)
            }
            guard !buckets.isEmpty else { throw StudioError.message("This image has no visible colors.") }
            let ranked = buckets.sorted { a, b in a.value.count == b.value.count ? a.key < b.key : a.value.count > b.value.count }
                .map { entry in ExtractedColor(red: entry.value.r / entry.value.count, green: entry.value.g / entry.value.count, blue: entry.value.b / entry.value.count) }
            var selected: [ExtractedColor] = []
            for candidate in ranked {
                try Task.checkCancellation()
                let distinct = selected.allSatisfy {
                    let r = candidate.red - $0.red, g = candidate.green - $0.green, b = candidate.blue - $0.blue
                    return r * r + g * g + b * b >= 45 * 45
                }
                if distinct { selected.append(candidate) }
                if selected.count == 6 { break }
            }
            return selected
        }
    }
}

struct PaletteStudioView: View {
    @EnvironmentObject private var store: ProjectStore
    @State private var selection: PhotosPickerItem?
    @State private var colors: [ExtractedColor] = []
    @State private var title = "My palette"
    @State private var busy = false
    @State private var error: String?
    @State private var exported: URL?
    @State private var copied: String?
    private let extractor = PaletteExtractor()
    var body: some View {
        ZStack {
            StudioBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    StudioCard {
                        VStack(alignment: .leading, spacing: 15) {
                            Label("Find your signature colors", systemImage: "eyedropper.halffull").font(.title2.bold())
                            Text("Extract a palette from any photo. Everything is processed on your device.").font(.subheadline).foregroundStyle(.secondary)
                            PhotosPicker(selection: $selection, matching: .images) {
                                Label("Choose photo", systemImage: "photo.badge.plus").font(.headline).frame(maxWidth: .infinity).padding(15).foregroundStyle(.white).background(studioGradient, in: RoundedRectangle(cornerRadius: 16))
                            }.buttonStyle(StudioPressStyle())
                        }
                    }
                    if busy { ProgressView("Extracting colors…").frame(maxWidth: .infinity) }
                    if !colors.isEmpty {
                        TextField("Palette name", text: $title).textFieldStyle(.roundedBorder)
                        HStack(spacing: 0) {
                            ForEach(colors) { swatch in swatch.color.frame(height: 110).accessibilityLabel(swatch.hex) }
                        }.clipShape(RoundedRectangle(cornerRadius: 24))
                        ForEach(colors) { swatch in
                            Button {
                                UIPasteboard.general.string = swatch.hex
                                copied = swatch.hex
                            } label: {
                                StudioCard {
                                    HStack {
                                        RoundedRectangle(cornerRadius: 14).fill(swatch.color).frame(width: 48, height: 48)
                                        Text(swatch.hex).font(.system(.headline, design: .monospaced)).foregroundStyle(.primary)
                                        Spacer()
                                        Image(systemName: copied == swatch.hex ? "checkmark.circle.fill" : "doc.on.doc").foregroundStyle(.secondary)
                                    }
                                }
                            }.buttonStyle(StudioPressStyle()).accessibilityHint("Copy HEX color")
                        }
                        HStack {
                            Button("Save palette JSON", systemImage: "curlybraces") { saveJSON() }
                            Spacer()
                            Button("Export palette PNG", systemImage: "photo") { savePNG() }
                        }.buttonStyle(.bordered)
                    } else if !busy {
                        ContentUnavailableView("Your next palette starts here", systemImage: "paintpalette", description: Text("Choose a photo to discover up to six dominant, distinct colors."))
                    }
                    if let exported { ShareLink(item: exported) { Label("Export file", systemImage: "square.and.arrow.up") } }
                    ErrorBanner(message: error)
                }.padding(20).frame(maxWidth: 800).frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("Palette Studio")
        .task(id: selection) {
            guard let selection else { return }
            busy = true; error = nil; copied = nil; exported = nil
            defer { busy = false }
            do {
                guard let data = try await selection.loadTransferable(type: Data.self) else { throw StudioError.message("Unable to open photo.") }
                let extracted = try await extractor.extract(data)
                try Task.checkCancellation()
                colors = extracted
            } catch is CancellationError { }
            catch { if !Task.isCancelled { self.error = error.localizedDescription } }
        }
    }
    private func saveJSON() {
        do {
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let document = PaletteDocument(name: title, colors: colors.map { PaletteEntry(hex: $0.hex, red: $0.red, green: $0.green, blue: $0.blue) })
            exported = try store.save(encoder.encode(document), name: title, ext: "json")
        } catch { self.error = error.localizedDescription }
    }
    private func savePNG() {
        let artwork = VStack(alignment: .leading, spacing: 24) {
            Text(title).font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(3)
            HStack(spacing: 0) {
                ForEach(colors) { swatch in
                    VStack(spacing: 12) {
                        swatch.color.frame(height: 260)
                        Text(swatch.hex).font(.system(size: 12, weight: .medium, design: .monospaced)).foregroundStyle(.white)
                    }.frame(maxWidth: .infinity)
                }
            }
            Text("HAIDER STUDIO").font(.system(size: 12, weight: .bold)).tracking(4).foregroundStyle(.gray)
        }.padding(32).frame(width: 600).background(Color(red: 0.03, green: 0.03, blue: 0.07))
        let renderer = ImageRenderer(content: artwork); renderer.scale = 2
        do {
            guard let data = renderer.uiImage?.pngData() else { throw StudioError.message("Palette rendering failed.") }
            exported = try store.save(data, name: title, ext: "png")
        } catch { self.error = error.localizedDescription }
    }
}
private struct PaletteEntry: Encodable { let hex: String; let red: Int; let green: Int; let blue: Int }
private struct PaletteDocument: Encodable { let name: String; let colors: [PaletteEntry] }
