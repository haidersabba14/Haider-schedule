import SwiftUI
import CoreText

struct TextToPDFView: View {
    @EnvironmentObject private var store: ProjectStore
    @State private var title = ""
    @State private var text = ""
    @State private var fontSize = 17.0
    @State private var exported: URL?
    @State private var error: String?
    var body: some View {
        Form {
            Section("Document title") { TextField("Title", text: $title) }
            Section("Document text") { TextEditor(text: $text).frame(minHeight: 260) }
            Section("Font size") { Slider(value: $fontSize, in: 12...30, step: 1); Text(fontSize.formatted()) }
            Text("Creates an A4 PDF with automatic pagination. Maximum 50,000 characters.").font(.caption).foregroundStyle(.secondary)
            Button("Create PDF") { create() }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || text.count > 50_000)
            if let exported { ShareLink(item: exported) }
            ErrorBanner(message: error)
        }.navigationTitle("Text to PDF")
    }
    private func create() {
        let paragraph = NSMutableParagraphStyle(); paragraph.alignment = .natural; paragraph.lineSpacing = 5
        let attributed = NSAttributedString(string: title.isEmpty ? text : title + "\n\n" + text, attributes: [.font: UIFont.systemFont(ofSize: fontSize), .paragraphStyle: paragraph, .foregroundColor: UIColor.black])
        let setter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let page = CGRect(x: 0, y: 0, width: 595.28, height: 841.89)
        let content = page.insetBy(dx: 36, dy: 40)
        var failure = false
        let data = UIGraphicsPDFRenderer(bounds: page).pdfData { renderer in
            var offset = 0
            while offset < attributed.length {
                renderer.beginPage()
                let context = renderer.cgContext
                context.saveGState(); context.translateBy(x: 0, y: page.height); context.scaleBy(x: 1, y: -1)
                let frame = CTFramesetterCreateFrame(setter, CFRange(location: offset, length: 0), CGPath(rect: content, transform: nil), nil)
                let visible = CTFrameGetVisibleStringRange(frame)
                guard visible.length > 0 else { context.restoreGState(); failure = true; break }
                CTFrameDraw(frame, context); context.restoreGState()
                offset += visible.length
            }
        }
        do {
            guard !failure else { throw StudioError.message("PDF layout failed.") }
            exported = try store.save(data, name: title.isEmpty ? "Document" : title, ext: "pdf")
        } catch { self.error = error.localizedDescription }
    }
}
