import SwiftUI

struct DesignStudioView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var title = "HAIDER"
    @State private var subtitle = "CREATE WITHOUT LIMITS"
    @State private var foreground = Color.white
    @State private var first = Color.purple
    @State private var second = Color.blue
    @State private var font = 60.0
    @State private var portrait = true
    @State private var exported: URL?
    @State private var error: String?
    private var artwork: some View {
        ZStack {
            LinearGradient(colors: [first, second, .black], startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle().stroke(foreground.opacity(0.2), lineWidth: 3).padding(30)
            VStack(spacing: 24) { Text(title).font(.system(size: font, weight: .black, design: .rounded)); Text(subtitle).font(.system(size: 18, weight: .medium)).tracking(3) }.foregroundStyle(foreground).multilineTextAlignment(.center).padding(30)
        }.frame(width: 360, height: portrait ? 640 : 360).clipped()
    }
    var body: some View {
        ScrollView {
            VStack {
                artwork.scaleEffect(0.8).frame(height: portrait ? 520 : 300)
                TextField("Title", text: $title).textFieldStyle(.roundedBorder)
                TextField("Subtitle", text: $subtitle).textFieldStyle(.roundedBorder)
                Slider(value: $font, in: 20...100)
                ColorPicker("Text color", selection: $foreground)
                ColorPicker("First color", selection: $first)
                ColorPicker("Second color", selection: $second)
                Toggle("Wallpaper portrait", isOn: $portrait)
                Button("Export PNG (1080 px)") {
                    let renderer = ImageRenderer(content: artwork); renderer.scale = 3
                    do {
                        guard let data = renderer.uiImage?.pngData() else { throw StudioError.message("Rendering failed.") }
                        exported = try store.save(data, name: portrait ? "Wallpaper" : "Design", ext: "png")
                    } catch { self.error = error.localizedDescription }
                }.buttonStyle(.borderedProminent)
                if let exported { ShareLink(item: exported) }
                ErrorBanner(message: error)
            }.padding()
        }.navigationTitle("Design Studio")
    }
}
