import SwiftUI
import WebKit
import UniformTypeIdentifiers

struct CodeStudioView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var code = "<!doctype html>\n<html lang=\"ar\" dir=\"rtl\">\n<meta name=\"viewport\" content=\"width=device-width\">\n<style>body { font-family:system-ui; background:#101020; color:#bbaaff; padding:24px }</style>\n<h1>HAIDER STUDIO</h1>\n<p>ابدأ البرمجة هنا</p>\n</html>"
    @State private var preview = false
    @State private var find = ""
    @State private var replacement = ""
    @State private var error: String?
    @State private var exported: URL?
    var body: some View {
        VStack {
            HStack { TextField("Find", text: $find); TextField("Replace", text: $replacement); Button("Replace all") { if !find.isEmpty { code = code.replacingOccurrences(of: find, with: replacement) } } }.padding(.horizontal)
            TextEditor(text: $code).font(.system(.body, design: .monospaced)).environment(\.layoutDirection, .leftToRight).autocorrectionDisabled().textInputAutocapitalization(.never)
            HStack {
                Button("Preview HTML") { preview = true }
                Button("Validate JSON") { do { _ = try JSONSerialization.jsonObject(with: Data(code.utf8), options: [.fragmentsAllowed]); error = "Valid JSON" } catch { self.error = error.localizedDescription } }
                Button("Save HTML") { do { exported = try store.save(Data(code.utf8), name: "Web page", ext: "html") } catch { self.error = error.localizedDescription } }
            }.padding()
            if let exported { ShareLink(item: exported) }
            ErrorBanner(message: error)
        }.navigationTitle("Code Studio").sheet(isPresented: $preview) {
            NavigationStack { LocalHTMLPreview(html: code).navigationTitle("Local HTML preview").toolbar { Button("Done") { preview = false } } }
        }
    }
}
struct LocalHTMLPreview: UIViewRepresentable {
    let html: String
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        config.limitsNavigationsToAppBoundDomains = true
        return WKWebView(frame: .zero, configuration: config)
    }
    func updateUIView(_ view: WKWebView, context: Context) {
        // Local preview blocks network resources. Script execution remains confined to WKWebView.
        let policy = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; form-action 'none'; frame-src 'none'\">"
        view.loadHTMLString(policy + html, baseURL: nil)
    }
}
