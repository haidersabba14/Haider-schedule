import Foundation
import Combine
import Network

@MainActor
final class ConnectionMonitor: ObservableObject {
    @Published var online = false
    @Published var checking = true
    private let monitor = NWPathMonitor()
    private var task: Task<Void, Never>?
    private var hasPath = false
    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor in
                guard let self else { return }
                self.hasPath = path.status == .satisfied
                if self.hasPath { self.retry() } else { self.online = false; self.checking = false }
            }
        }
        monitor.start(queue: DispatchQueue(label: "studio.connectivity"))
        task = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(15))
                guard !Task.isCancelled else { break }
                await self?.check()
            }
        }
    }
    func retry() { Task { await check() } }
    func check() async {
        guard hasPath else { online = false; checking = false; return }
        checking = true
        defer { checking = false }
        do {
            var request = URLRequest(url: URL(string: "https://www.apple.com/library/test/success.html")!)
            request.timeoutInterval = 8
            request.cachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await URLSession.shared.data(for: request)
            online = (response as? HTTPURLResponse)?.statusCode == 200 && String(decoding: data, as: UTF8.self).contains("<TITLE>Success</TITLE>")
        } catch { online = false }
    }
    deinit { monitor.cancel(); task?.cancel() }
}
