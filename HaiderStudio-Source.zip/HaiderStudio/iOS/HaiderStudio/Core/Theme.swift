import SwiftUI

let studioGradient = LinearGradient(colors: [.purple, .blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
struct StudioBackground: View {
    var body: some View {
        ZStack { Color(.systemBackground); studioGradient.opacity(0.13); Circle().fill(.purple.opacity(0.15)).blur(radius: 80).offset(x: 130, y: -250) }.ignoresSafeArea()
    }
}
struct StudioCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View { content.padding().background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)).overlay(RoundedRectangle(cornerRadius: 22).stroke(.purple.opacity(0.25))) }
}
struct ErrorBanner: View {
    let message: String?
    var body: some View { if let message { Text(message).font(.callout).foregroundStyle(.red).textSelection(.enabled).padding() } }
}
