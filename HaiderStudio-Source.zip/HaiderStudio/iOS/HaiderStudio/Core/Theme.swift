import SwiftUI

let studioGradient = LinearGradient(colors: [.purple, .blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing)

enum StudioAccent: String, CaseIterable, Identifiable {
    case aurora, ocean, rose
    var id: String { rawValue }
    var title: String { switch self { case .aurora: "Aurora"; case .ocean: "Ocean"; case .rose: "Rose" } }
    var colors: [Color] { switch self { case .aurora: [.purple, .blue, .cyan]; case .ocean: [.blue, .teal, .cyan]; case .rose: [.pink, .purple, .indigo] } }
    var gradient: LinearGradient { LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing) }
}

struct StudioBackground: View {
    @Environment(\.colorScheme) private var scheme
    @AppStorage("studioAccent") private var accent = "aurora"
    private var palette: StudioAccent { StudioAccent(rawValue: accent) ?? .aurora }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color(.systemBackground)
                if scheme == .dark { Color(red: 0.025, green: 0.025, blue: 0.065) }
                Ellipse().fill(palette.colors[0].opacity(scheme == .dark ? 0.24 : 0.12))
                    .frame(width: geometry.size.width * 1.1, height: 380).blur(radius: 95).offset(x: 120, y: -260)
                Ellipse().fill(palette.colors[2].opacity(0.10))
                    .frame(width: 280, height: 470).blur(radius: 90).offset(x: -160, y: 280)
            }
        }.ignoresSafeArea().accessibilityHidden(true)
    }
}

struct StudioCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous)
                .stroke(LinearGradient(colors: [.white.opacity(0.28), .purple.opacity(0.1), .cyan.opacity(0.16)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
            .shadow(color: .black.opacity(0.08), radius: 20, y: 10)
    }
}

struct StudioPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.975 : 1)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

struct StudioSectionHeading: View {
    let title: LocalizedStringKey
    let symbol: String
    var body: some View {
        Label(title, systemImage: symbol).font(.title3.weight(.bold)).frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct ErrorBanner: View {
    let message: String?
    var body: some View { if let message { Text(message).font(.callout).foregroundStyle(.red).textSelection(.enabled).padding() } }
}
