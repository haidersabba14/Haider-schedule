import Foundation
import Combine
import UniformTypeIdentifiers

struct StudioProject: Identifiable, Codable {
    let id: UUID
    var name: String
    let filename: String
    let created: Date
}

@MainActor
final class ProjectStore: ObservableObject {
    @Published private(set) var items: [StudioProject] = []
    @Published var error: String?
    private let directory: URL
    private var writable = true
    init() {
        directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Projects", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let index = directory.appendingPathComponent("index.json")
            if FileManager.default.fileExists(atPath: index.path) {
                items = try JSONDecoder().decode([StudioProject].self, from: Data(contentsOf: index))
            }
        } catch { self.error = error.localizedDescription; writable = false }
    }
    func url(_ item: StudioProject) -> URL { directory.appendingPathComponent(item.filename) }
    @discardableResult
    func save(_ data: Data, name: String, ext: String) throws -> URL {
        guard writable else { throw StudioError.message("Project index could not be read. Export existing files before repairing it.") }
        let id = UUID()
        let filename = id.uuidString + "." + ext
        let location = directory.appendingPathComponent(filename)
        try data.write(to: location, options: [.atomic, .completeFileProtection])
        let item = StudioProject(id: id, name: name.isEmpty ? "Untitled" : name, filename: filename, created: Date())
        let updated = [item] + items
        do { try persist(updated); items = updated }
        catch { try? FileManager.default.removeItem(at: location); throw error }
        return location
    }
    func importFile(_ url: URL) throws {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey])
        guard (values.fileSize ?? 0) <= 200_000_000 else { throw StudioError.message("Maximum file size is 200 MB.") }
        try save(Data(contentsOf: url), name: url.deletingPathExtension().lastPathComponent, ext: url.pathExtension)
    }
    func delete(_ item: StudioProject) throws {
        guard writable else { throw StudioError.message("Project index is unavailable.") }
        let updated = items.filter { $0.id != item.id }
        // Commit the index atomically first. If file removal fails, restore the old index.
        try persist(updated)
        do { try FileManager.default.removeItem(at: url(item)) }
        catch { try persist(items); throw error }
        items = updated
    }
    private func persist(_ value: [StudioProject]) throws {
        try JSONEncoder().encode(value).write(to: directory.appendingPathComponent("index.json"), options: [.atomic, .completeFileProtection])
    }
}
enum StudioError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(value) = self { return value }; return nil }
}
