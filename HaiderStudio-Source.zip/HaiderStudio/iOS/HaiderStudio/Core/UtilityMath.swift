import Foundation

enum UtilityMath {
    enum Failure: Error { case invalidInput, undefinedResult }
    static func number(_ input: String) -> Double? {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        var normalized = ""
        for character in trimmed {
            if let digit = character.wholeNumberValue, (0...9).contains(digit) { normalized += String(digit) }
            else if character == "٫" || character == "," { normalized += "." }
            else if character == "−" { normalized += "-" }
            else { normalized.append(character) }
        }
        guard normalized.range(of: "^[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?$", options: .regularExpression) != nil,
              let number = Double(normalized), number.isFinite else { return nil }
        return number
    }
    static func convert(_ value: Double, sourceFactor: Double, sourceOffset: Double, targetFactor: Double, targetOffset: Double, temperature: Bool = false) throws -> Double {
        guard value.isFinite, sourceFactor.isFinite, targetFactor.isFinite, sourceFactor > 0, targetFactor > 0 else { throw Failure.invalidInput }
        let base = value * sourceFactor + sourceOffset
        if temperature && base < -273.150000001 { throw Failure.invalidInput }
        let result = (base - targetOffset) / targetFactor
        guard result.isFinite else { throw Failure.undefinedResult }
        return result
    }
    static func calculate(_ operation: String, a: Double, b: Double? = nil, degrees: Bool = true) throws -> Double {
        guard a.isFinite else { throw Failure.invalidInput }
        if ["+", "−", "×", "÷", "xʸ"].contains(operation), b?.isFinite != true { throw Failure.invalidInput }
        let angle = degrees ? a * .pi / 180 : a
        let value: Double
        switch operation {
        case "+": value = a + (b ?? 0)
        case "−": value = a - (b ?? 0)
        case "×": value = a * (b ?? 0)
        case "÷": guard b != 0 else { throw Failure.undefinedResult }; value = a / (b ?? 1)
        case "xʸ": value = pow(a, b ?? 0)
        case "sin": value = sin(angle)
        case "cos": value = cos(angle)
        case "tan": guard abs(cos(angle)) > 1e-12 else { throw Failure.undefinedResult }; value = tan(angle)
        case "√": value = sqrt(a)
        case "ln": value = log(a)
        case "log₁₀": value = log10(a)
        case "x²": value = a * a
        case "1/x": guard a != 0 else { throw Failure.undefinedResult }; value = 1 / a
        case "n!":
            guard a >= 0, a <= 170, a.rounded() == a else { throw Failure.invalidInput }
            value = a < 2 ? 1 : (2...Int(a)).reduce(1.0) { $0 * Double($1) }
        default: throw Failure.invalidInput
        }
        guard value.isFinite else { throw Failure.undefinedResult }
        return value
    }
}
